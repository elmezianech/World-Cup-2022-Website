//slider start
var counter = 1;
    setInterval(function(){
    document.getElementById('radio' + counter).checked = true;
    counter++;
    if(counter > 4){
      counter = 1;
    }
    }, 5000);
//slider end




document.getElementById("pub1").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}

document.getElementById("pub2").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}

document.getElementById("pub3").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}

document.getElementById("pub4").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}

document.getElementById("pub5").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}

document.getElementById("pub6").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}

document.getElementById("pub7").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}

document.getElementById("pub8").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}

document.getElementById("pub9").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}
document.getElementById("pub10").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}
document.getElementById("pub11").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}
document.getElementById("pub12").onclick = function() {
    document.getElementById("pubframe").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
}


//VOLET 2
document.getElementById("grp1").onclick = function() {
    document.getElementById("groupA").style.display = "block";
    document.getElementById("container1").style.display = "block";
    document.getElementById("accueil2").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("groupB").style.display = "none";
    document.getElementById("groupC").style.display = "none";
    document.getElementById("groupD").style.display = "none";
    document.getElementById("groupE").style.display = "none";
    document.getElementById("groupF").style.display = "none";
    document.getElementById("groupG").style.display = "none";
    document.getElementById("groupH").style.display = "none";
    document.getElementById("volet5").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

document.getElementById("grp2").onclick = function() {
    document.getElementById("groupB").style.display = "block";
    document.getElementById("container1").style.display = "block";
    document.getElementById("accueil2").style.display = "block";
  
    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("groupA").style.display = "none";
    document.getElementById("groupC").style.display = "none";
    document.getElementById("groupD").style.display = "none";
    document.getElementById("groupE").style.display = "none";
    document.getElementById("groupF").style.display = "none";
    document.getElementById("groupG").style.display = "none";
    document.getElementById("groupH").style.display = "none";
    document.getElementById("volet5").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
  }
  
document.getElementById("grp3").onclick = function() {
    document.getElementById("groupC").style.display = "block";
    document.getElementById("container1").style.display = "block";
    document.getElementById("accueil2").style.display = "block";
  
    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("groupA").style.display = "none";
    document.getElementById("groupB").style.display = "none";
    document.getElementById("groupD").style.display = "none";
    document.getElementById("groupE").style.display = "none";
    document.getElementById("groupF").style.display = "none";
    document.getElementById("groupG").style.display = "none";
    document.getElementById("groupH").style.display = "none";
    document.getElementById("volet5").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}
  
document.getElementById("grp4").onclick = function() {
    document.getElementById("groupD").style.display = "block";
    document.getElementById("container1").style.display = "block";
    document.getElementById("accueil2").style.display = "block";
  
    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("groupA").style.display = "none";
    document.getElementById("groupB").style.display = "none";
    document.getElementById("groupC").style.display = "none";
    document.getElementById("groupE").style.display = "none";
    document.getElementById("groupF").style.display = "none";
    document.getElementById("groupG").style.display = "none";
    document.getElementById("groupH").style.display = "none";
    document.getElementById("volet5").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}
  
document.getElementById("grp5").onclick = function() {
    document.getElementById("groupE").style.display = "block";
    document.getElementById("container1").style.display = "block";
    document.getElementById("accueil2").style.display = "block";
  
    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("groupA").style.display = "none";
    document.getElementById("groupB").style.display = "none";
    document.getElementById("groupC").style.display = "none";
    document.getElementById("groupD").style.display = "none";
    document.getElementById("groupF").style.display = "none";
    document.getElementById("groupG").style.display = "none";
    document.getElementById("groupH").style.display = "none";
    document.getElementById("volet5").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}
  
document.getElementById("grp6").onclick = function() {
    document.getElementById("groupF").style.display = "block";
    document.getElementById("container1").style.display = "block";
    document.getElementById("accueil2").style.display = "block";
  
    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("groupA").style.display = "none";
    document.getElementById("groupB").style.display = "none";
    document.getElementById("groupC").style.display = "none";
    document.getElementById("groupD").style.display = "none";
    document.getElementById("groupE").style.display = "none";
    document.getElementById("groupG").style.display = "none";
    document.getElementById("groupH").style.display = "none";
    document.getElementById("volet5").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}
  
document.getElementById("grp7").onclick = function() {
    document.getElementById("groupG").style.display = "block";
    document.getElementById("container1").style.display = "block";
    document.getElementById("accueil2").style.display = "block";
  
    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("groupA").style.display = "none";
    document.getElementById("groupB").style.display = "none";
    document.getElementById("groupC").style.display = "none";
    document.getElementById("groupD").style.display = "none";
    document.getElementById("groupE").style.display = "none";
    document.getElementById("groupF").style.display = "none";
    document.getElementById("groupH").style.display = "none";
    document.getElementById("volet5").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}
  
document.getElementById("grp8").onclick = function() {
    document.getElementById("groupH").style.display = "block";
    document.getElementById("container1").style.display = "block";
    document.getElementById("accueil2").style.display = "block";
  
    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("groupA").style.display = "none";
    document.getElementById("groupB").style.display = "none";
    document.getElementById("groupC").style.display = "none";
    document.getElementById("groupD").style.display = "none";
    document.getElementById("groupE").style.display = "none";
    document.getElementById("groupF").style.display = "none";
    document.getElementById("groupG").style.display = "none";
    document.getElementById("volet5").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}




//QATAR

//VOLET 3
document.getElementById("qatar").onclick = function() {
    document.getElementById("photoclic").style.display = "block";
    document.getElementById("volet4").style.display = "block";
    
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

//VOLET 4
document.getElementById("joueur1").onclick = function() {
    document.getElementById("SaadAlSheeb").style.display = "block";
    
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("volet4").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

document.getElementById("joueur2").onclick = function() {
    document.getElementById("MeshaalBarsham").style.display = "block";
    
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("volet4").style.display = "none";
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

document.getElementById("joueur3").onclick = function() {
    document.getElementById("PedroMiguel").style.display = "block";
    
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("volet4").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

//ECUADOR
document.getElementById("ecuador").onclick = function() {
    document.getElementById("photoclic2").style.display = "block";

    document.getElementById("volet4").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

document.getElementById("plyr1").onclick = function() {
    document.getElementById("PieroHincapié").style.display = "block";
    
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("volet4").style.display = "none";
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

document.getElementById("plyr2").onclick = function() {
    document.getElementById("AngeloPreciado").style.display = "block";
    
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("volet4").style.display = "none";
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

document.getElementById("plyr3").onclick = function() {
    document.getElementById("MoisésCaicedo").style.display = "block";
    
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("volet4").style.display = "none";
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

//SENEGAL
document.getElementById("senegal").onclick = function() {
    document.getElementById("photoclic3").style.display = "block";

    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

document.getElementById("jr1").onclick = function() {
    document.getElementById("EdouardMENDY").style.display = "block";
    
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("volet4").style.display = "none";
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

document.getElementById("jr2").onclick = function() {
    document.getElementById("GanaGUEYE").style.display = "block";
    
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("volet4").style.display = "none";
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

document.getElementById("jr3").onclick = function() {
    document.getElementById("MENDY").style.display = "block";
    
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("volet4").style.display = "none";
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}


//PAYS-BAS
document.getElementById("netherlands").onclick = function() {
    document.getElementById("photoclic4").style.display = "block";

    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

document.getElementById("player1").onclick = function() {
    document.getElementById("JustinBijlow").style.display = "block";

    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
}

document.getElementById("player2").onclick = function() {
    document.getElementById("VirgilVanDijk").style.display = "block";

    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
}

document.getElementById("player3").onclick = function() {
    document.getElementById("MemphisDepay").style.display = "block";

    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("accueil2").style.display = "none"; 
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}

//tableau start
function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
	
 var name=document.getElementById("name_row"+no);
 var country=document.getElementById("country_row"+no);
 var age=document.getElementById("age_row"+no);
	
 var name_data=name.innerHTML;
 var country_data=country.innerHTML;
 var age_data=age.innerHTML;
	
 name.innerHTML="<input type='text' id='name_text"+no+"' value='"+name_data+"'>";
 country.innerHTML="<input type='text' id='country_text"+no+"' value='"+country_data+"'>";
 age.innerHTML="<input type='text' id='age_text"+no+"' value='"+age_data+"'>";
}

function save_row(no)
{
 var name_val=document.getElementById("name_text"+no).value;
 var country_val=document.getElementById("country_text"+no).value;
 var age_val=document.getElementById("age_text"+no).value;

 document.getElementById("name_row"+no).innerHTML=name_val;
 document.getElementById("country_row"+no).innerHTML=country_val;
 document.getElementById("age_row"+no).innerHTML=age_val;

 document.getElementById("edit_button"+no).style.display="block";
 document.getElementById("save_button"+no).style.display="none";
}

function delete_row(no)
{
 document.getElementById("row"+no+"").outerHTML="";
}

function add_row()
{
 var new_name=document.getElementById("new_name").value;
 var new_country=document.getElementById("new_country").value;
 var new_age=document.getElementById("new_age").value;
	
 var table=document.getElementById("data_table");
 var table_len=(table.rows.length)-1;
 var row = table.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='name_row"+table_len+"'>"+new_name+"</td><td id='country_row"+table_len+"'>"+new_country+"</td><td id='age_row"+table_len+"'>"+new_age+"</td><td><input type='button' id='edit_button"+table_len+"' value='Edit' class='edit' onclick='edit_row("+table_len+")'> <input type='button' id='save_button"+table_len+"' value='Save' class='save' onclick='save_row("+table_len+")'> <input type='button' value='Delete' class='delete' onclick='delete_row("+table_len+")'></td></tr>";

 document.getElementById("new_name").value="";
 document.getElementById("new_country").value="";
 document.getElementById("new_age").value="";
}
//tableau end

document.getElementById("acc").onclick = function() {
    document.getElementById("accueil").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}

document.getElementById("match").onclick = function() {
    document.getElementById("volet5").style.display = "block";
    document.getElementById("matchs").style.display = "block";

    document.getElementById("container1").style.display = "none";
    document.getElementById("accueil").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}
  
document.getElementById("classement").onclick = function() {
    document.getElementById("volet5").style.display = "block";
    document.getElementById("evr").style.display = "block";

    document.getElementById("container1").style.display = "none";
    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}


//footer
document.getElementById("facc").onclick = function() {
    document.getElementById("accueil").style.display = "block";
    document.getElementById("volet5").style.display = "block";

    document.getElementById("container1").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}

document.getElementById("fmatch").onclick = function() {
    document.getElementById("volet5").style.display = "block";
    document.getElementById("matchs").style.display = "block";

    document.getElementById("container1").style.display = "none";
    document.getElementById("accueil").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}
  
document.getElementById("fclassement").onclick = function() {
    document.getElementById("volet5").style.display = "block";
    document.getElementById("evr").style.display = "block";

    document.getElementById("container1").style.display = "none";
    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
}

document.getElementById("fgrp1").onclick = function() {
    document.getElementById("groupA").style.display = "block";
    document.getElementById("container1").style.display = "block";
    document.getElementById("accueil2").style.display = "block";

    document.getElementById("accueil").style.display = "none";
    document.getElementById("matchs").style.display = "none";
    document.getElementById("evr").style.display = "none";
    document.getElementById("groupB").style.display = "none";
    document.getElementById("groupC").style.display = "none";
    document.getElementById("groupD").style.display = "none";
    document.getElementById("groupE").style.display = "none";
    document.getElementById("groupF").style.display = "none";
    document.getElementById("groupG").style.display = "none";
    document.getElementById("groupH").style.display = "none";
    document.getElementById("volet5").style.display = "none";
    document.getElementById("photoclic").style.display = "none";
    document.getElementById("volet4").style.display = "none";
    document.getElementById("photoclic2").style.display = "none";
    document.getElementById("volet4-2").style.display = "none";
    document.getElementById("pubframe").style.display = "none";
    document.getElementById("photoclic3").style.display = "none";
    document.getElementById("photoclic4").style.display = "none";
    document.getElementById("SaadAlSheeb").style.display = "none";
    document.getElementById("MeshaalBarsham").style.display = "none";
    document.getElementById("PedroMiguel").style.display = "none";
    document.getElementById("PieroHincapié").style.display = "none";
    document.getElementById("AngeloPreciado").style.display = "none";
    document.getElementById("MoisésCaicedo").style.display = "none";
    document.getElementById("GanaGUEYE").style.display = "none";
    document.getElementById("MENDY").style.display = "none";
    document.getElementById("EdouardMENDY").style.display = "none";
    document.getElementById("VirgilVanDijk").style.display = "none";
    document.getElementById("MemphisDepay").style.display = "none";
    document.getElementById("JustinBijlow").style.display = "none";
}
